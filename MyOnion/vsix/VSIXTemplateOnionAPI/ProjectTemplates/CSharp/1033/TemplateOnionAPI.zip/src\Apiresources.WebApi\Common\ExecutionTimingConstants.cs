﻿namespace $safeprojectname$.Common
{
    internal static class ExecutionTimingConstants
    {
        public const string StopwatchItemKey = "__$ext_projectname$.ExecutionTiming.Stopwatch";
        public const string ElapsedItemKey = "__$ext_projectname$.ExecutionTiming.Elapsed";
    }
}

