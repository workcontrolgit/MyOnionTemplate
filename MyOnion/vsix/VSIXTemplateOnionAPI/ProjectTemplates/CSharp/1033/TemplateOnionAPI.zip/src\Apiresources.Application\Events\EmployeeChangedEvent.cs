﻿#nullable enable
namespace $safeprojectname$.Events;

public sealed record EmployeeChangedEvent(Guid EmployeeId) : IDomainEvent;

