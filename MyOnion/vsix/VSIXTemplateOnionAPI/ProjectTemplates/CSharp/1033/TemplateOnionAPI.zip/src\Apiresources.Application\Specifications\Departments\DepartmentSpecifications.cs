﻿namespace $safeprojectname$.Specifications.Departments
{
    public class DepartmentsByFiltersSpecification : BaseSpecification<Department>
    {
        public DepartmentsByFiltersSpecification(GetDepartmentsQuery request, bool applyPaging = true)
            : base(BuildFilterExpression(request))
        {
            var orderBy = ResolveOrderBy(request.OrderBy);
            ApplyOrderBy(orderBy);

            if (applyPaging && request.PageSize > 0)
            {
                ApplyPaging((request.PageNumber - 1) * request.PageSize, request.PageSize);
            }
        }

        private static Expression<Func<Department, bool>> BuildFilterExpression(GetDepartmentsQuery request)
        {
            var predicate = PredicateBuilder.New<Department>(true);

            if (!string.IsNullOrWhiteSpace(request.Name))
            {
                var term = request.Name.Trim();
                predicate = predicate.And(d => d.Name.Value.Contains(term));
            }

            return predicate.IsStarted ? predicate : null;
        }

        private static string ResolveOrderBy(string orderBy)
        {
            if (string.IsNullOrWhiteSpace(orderBy))
            {
                return "Name.Value";
            }

            return orderBy switch
            {
                "Name" => "Name.Value",
                _ => orderBy
            };
        }
    }
}

