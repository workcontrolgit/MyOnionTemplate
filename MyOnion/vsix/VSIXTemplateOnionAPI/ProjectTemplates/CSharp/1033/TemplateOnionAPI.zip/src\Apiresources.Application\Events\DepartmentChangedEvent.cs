﻿#nullable enable
namespace $safeprojectname$.Events;

public sealed record DepartmentChangedEvent(Guid DepartmentId) : IDomainEvent;

