﻿#nullable enable
namespace $safeprojectname$.Events;

public sealed record PositionChangedEvent(Guid PositionId) : IDomainEvent;

