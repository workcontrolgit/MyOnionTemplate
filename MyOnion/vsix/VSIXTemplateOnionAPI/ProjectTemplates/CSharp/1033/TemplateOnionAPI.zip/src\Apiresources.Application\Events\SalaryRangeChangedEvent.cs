﻿#nullable enable
namespace $safeprojectname$.Events;

public sealed record SalaryRangeChangedEvent(Guid SalaryRangeId) : IDomainEvent;

