﻿using Microsoft.AspNetCore.Builder;

namespace $safeprojectname$.Middlewares;

public static class CacheBypassMiddlewareExtensions
{
    public static IApplicationBuilder UseCacheBypassMiddleware(this IApplicationBuilder builder)
        => builder.UseMiddleware<CacheBypassMiddleware>();
}

