﻿using $safeprojectname$.Features.Dashboard.Queries.GetDashboardMetrics;

namespace $safeprojectname$.Interfaces;

public interface IDashboardMetricsReader
{
    Task<DashboardMetricsDto> GetDashboardMetricsAsync(CancellationToken ct);
}

