﻿global using System;
global using System.Collections;
global using System.Collections.Generic;
global using System.Dynamic;
global using System.Xml;
global using System.Xml.Schema;
global using System.Xml.Serialization;
global using $safeprojectname$.Common;
global using $safeprojectname$.Enums;

