﻿namespace $safeprojectname$.Interfaces.Caching;

public interface ICacheKeyHasher
{
    string Hash(string cacheKey);
}

