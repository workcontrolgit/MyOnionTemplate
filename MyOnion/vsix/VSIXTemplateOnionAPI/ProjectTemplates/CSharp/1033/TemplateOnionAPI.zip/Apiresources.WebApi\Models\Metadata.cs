﻿namespace $safeprojectname$.Models
{
    // Represents metadata information
    public class Metadata

    {
    }
}
